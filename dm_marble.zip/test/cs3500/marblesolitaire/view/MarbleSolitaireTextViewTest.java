package cs3500.marblesolitaire.view;

import org.junit.Assert;
import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;

/**
 * This class tests the method in the MarbleSolitaireTextView class.
 */
public class MarbleSolitaireTextViewTest {

  EnglishSolitaireModel model1 = new EnglishSolitaireModel();
  EnglishSolitaireModel model2 = new EnglishSolitaireModel(1);
  EnglishSolitaireModel model3 = new EnglishSolitaireModel(3, 0, 2);

  MarbleSolitaireTextView test1 = new MarbleSolitaireTextView(model1);
  MarbleSolitaireTextView test2 = new MarbleSolitaireTextView(model2);

  MarbleSolitaireTextView test3 = new MarbleSolitaireTextView(model3);

  /**
   * Test to make sure that the toString method is displaying the board correctly.
   */
  @Test
  public void toStringWorks() {
    Assert.assertEquals(test1.toString(), "    O O O    " + "\n" +
            "    O O O    " + "\n" + "O O O O O O O" + "\n" +
            "O O O _ O O O" + "\n" +
            "O O O O O O O" + "\n" +
            "    O O O    " + "\n" +
            "    O O O    ");
    Assert.assertEquals(test3.toString(), "    _ O O    " + "\n" +
            "    O O O    " + "\n" + "O O O O O O O" + "\n" +
            "O O O O O O O" + "\n" +
            "O O O O O O O" + "\n" +
            "    O O O    " + "\n" +
            "    O O O    ");
    Assert.assertEquals(test2.toString(), "_");

  }

}