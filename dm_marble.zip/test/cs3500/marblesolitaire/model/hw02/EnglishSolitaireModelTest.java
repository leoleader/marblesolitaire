package cs3500.marblesolitaire.model.hw02;

import org.junit.Assert;
import org.junit.Test;

/**
 * This class is the tests for the methods in EnglishSolitaireModel.
 */
public class EnglishSolitaireModelTest {
  EnglishSolitaireModel emptyModel = new EnglishSolitaireModel();
  EnglishSolitaireModel fullModel = new EnglishSolitaireModel(3, 3, 3);
  EnglishSolitaireModel armModel = new EnglishSolitaireModel(3);
  EnglishSolitaireModel rowColModel = new EnglishSolitaireModel(3, 3);

  @Test
  public void init_Board_Works() {
    Assert.assertEquals(emptyModel.board[1][1], MarbleSolitaireModelState.SlotState.Invalid);
    Assert.assertEquals(emptyModel.board[3][3], MarbleSolitaireModelState.SlotState.Empty);
    Assert.assertEquals(emptyModel.board[3][5], MarbleSolitaireModelState.SlotState.Marble);
    Assert.assertNotEquals(emptyModel.board[3][5], emptyModel.board[3][3]);

    Assert.assertEquals(fullModel.board[1][1], MarbleSolitaireModelState.SlotState.Invalid);
    Assert.assertEquals(fullModel.board[3][3], MarbleSolitaireModelState.SlotState.Empty);
    Assert.assertEquals(fullModel.board[3][5], MarbleSolitaireModelState.SlotState.Marble);
    Assert.assertEquals(fullModel.board[3][5], emptyModel.board[3][5]);
    Assert.assertThrows(IllegalArgumentException.class, () -> new EnglishSolitaireModel(3, 7, 20));

    Assert.assertEquals(armModel.board[1][1], MarbleSolitaireModelState.SlotState.Invalid);
    Assert.assertEquals(armModel.board[3][3], MarbleSolitaireModelState.SlotState.Empty);
    Assert.assertEquals(armModel.board[3][5], MarbleSolitaireModelState.SlotState.Marble);
    Assert.assertNotEquals(armModel.board[3][5], armModel.board[3][3]);
    Assert.assertThrows(IllegalArgumentException.class, () -> new EnglishSolitaireModel(4));
    Assert.assertThrows(IllegalArgumentException.class, () -> new EnglishSolitaireModel(-5));

    Assert.assertEquals(rowColModel.board[1][1], MarbleSolitaireModelState.SlotState.Invalid);
    Assert.assertEquals(rowColModel.board[3][3], MarbleSolitaireModelState.SlotState.Empty);
    Assert.assertEquals(rowColModel.board[3][5], MarbleSolitaireModelState.SlotState.Marble);
    Assert.assertNotEquals(rowColModel.board[3][5], rowColModel.board[3][3]);
    Assert.assertThrows(IllegalArgumentException.class, () -> new EnglishSolitaireModel(-10, 3));

  }

  @Test
  public void getBoardSize() {
    Assert.assertEquals(emptyModel.getBoardSize(), 7);
    Assert.assertEquals(new EnglishSolitaireModel(5).getBoardSize(), 13);
    Assert.assertEquals(new EnglishSolitaireModel(5, 7, 7).getBoardSize(), 13);
    Assert.assertEquals(rowColModel.getBoardSize(), 7);
  }

  @Test
  public void test_getSlot() {
    Assert.assertEquals(emptyModel.getSlotAt(1, 1), MarbleSolitaireModelState.SlotState.Invalid);
    Assert.assertEquals(emptyModel.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
    Assert.assertEquals(emptyModel.getSlotAt(3, 4), MarbleSolitaireModelState.SlotState.Marble);
    Assert.assertThrows(IllegalArgumentException.class, () -> emptyModel.getSlotAt(10, 10));
    Assert.assertThrows(IllegalArgumentException.class, () -> emptyModel.getSlotAt(3, -1));
  }

  @Test
  public void test_getScore() {
    Assert.assertEquals(emptyModel.getScore(), 32);
  }

  @Test
  public void test_move() {
    EnglishSolitaireModel moveModel = new EnglishSolitaireModel();
    Assert.assertEquals(moveModel.board[3][3], MarbleSolitaireModelState.SlotState.Empty);
    Assert.assertEquals(moveModel.board[3][5], MarbleSolitaireModelState.SlotState.Marble);
    moveModel.move(3, 5, 3, 3);

  }

  @Test
  public void isValidMove() {
    Assert.assertEquals(emptyModel.validMove(3, 5, 3, 3), true);
    Assert.assertEquals(emptyModel.validMove(0, 0, 0, 2), false);
    Assert.assertEquals(emptyModel.validMove(6, 6, 7, 7), false);
    Assert.assertEquals(emptyModel.validMove(10, 10, 10, 12), false);
  }

  @Test
  public void isGameOver() {
    Assert.assertEquals(emptyModel.isGameOver(), false);
  }
}